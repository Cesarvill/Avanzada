﻿namespace EnviodedatosRS232
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnBuscar = new System.Windows.Forms.Button();
            this.BtnConectar = new System.Windows.Forms.Button();
            this.BtnEnviar = new System.Windows.Forms.Button();
            this.CboPuertos = new System.Windows.Forms.ComboBox();
            this.CboBaudRate = new System.Windows.Forms.ComboBox();
            this.LblDatosIngreso = new System.Windows.Forms.Label();
            this.LblBaudrate = new System.Windows.Forms.Label();
            this.TxtDatosRecibidos = new System.Windows.Forms.TextBox();
            this.TxtDatosEnviar = new System.Windows.Forms.TextBox();
            this.SpPuertos = new System.IO.Ports.SerialPort(this.components);
            this.SuspendLayout();
            // 
            // BtnBuscar
            // 
            this.BtnBuscar.Location = new System.Drawing.Point(12, 69);
            this.BtnBuscar.Name = "BtnBuscar";
            this.BtnBuscar.Size = new System.Drawing.Size(101, 23);
            this.BtnBuscar.TabIndex = 0;
            this.BtnBuscar.Text = "Buscar puertos";
            this.BtnBuscar.UseVisualStyleBackColor = true;
            this.BtnBuscar.Click += new System.EventHandler(this.Button1_Click);
            // 
            // BtnConectar
            // 
            this.BtnConectar.Location = new System.Drawing.Point(294, 71);
            this.BtnConectar.Name = "BtnConectar";
            this.BtnConectar.Size = new System.Drawing.Size(97, 23);
            this.BtnConectar.TabIndex = 1;
            this.BtnConectar.Text = "CONECTAR";
            this.BtnConectar.UseVisualStyleBackColor = true;
            this.BtnConectar.Click += new System.EventHandler(this.Button2_Click);
            // 
            // BtnEnviar
            // 
            this.BtnEnviar.Location = new System.Drawing.Point(15, 192);
            this.BtnEnviar.Name = "BtnEnviar";
            this.BtnEnviar.Size = new System.Drawing.Size(75, 23);
            this.BtnEnviar.TabIndex = 2;
            this.BtnEnviar.Text = "Enviar Datos";
            this.BtnEnviar.UseVisualStyleBackColor = true;
            this.BtnEnviar.Click += new System.EventHandler(this.BtnEnviar_Click);
            // 
            // CboPuertos
            // 
            this.CboPuertos.FormattingEnabled = true;
            this.CboPuertos.Location = new System.Drawing.Point(135, 71);
            this.CboPuertos.Name = "CboPuertos";
            this.CboPuertos.Size = new System.Drawing.Size(121, 21);
            this.CboPuertos.TabIndex = 3;
            this.CboPuertos.SelectedIndexChanged += new System.EventHandler(this.CboPuertos_SelectedIndexChanged);
            // 
            // CboBaudRate
            // 
            this.CboBaudRate.FormattingEnabled = true;
            this.CboBaudRate.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600"});
            this.CboBaudRate.Location = new System.Drawing.Point(135, 133);
            this.CboBaudRate.Name = "CboBaudRate";
            this.CboBaudRate.Size = new System.Drawing.Size(121, 21);
            this.CboBaudRate.TabIndex = 4;
            this.CboBaudRate.Text = "9600";
            this.CboBaudRate.SelectedIndexChanged += new System.EventHandler(this.CboBaudRate_SelectedIndexChanged);
            // 
            // LblDatosIngreso
            // 
            this.LblDatosIngreso.AutoSize = true;
            this.LblDatosIngreso.Location = new System.Drawing.Point(12, 260);
            this.LblDatosIngreso.Name = "LblDatosIngreso";
            this.LblDatosIngreso.Size = new System.Drawing.Size(85, 13);
            this.LblDatosIngreso.TabIndex = 5;
            this.LblDatosIngreso.Text = "Datos Recibidos";
            this.LblDatosIngreso.Click += new System.EventHandler(this.LblDatosIngreso_Click);
            // 
            // LblBaudrate
            // 
            this.LblBaudrate.AutoSize = true;
            this.LblBaudrate.Location = new System.Drawing.Point(12, 141);
            this.LblBaudrate.Name = "LblBaudrate";
            this.LblBaudrate.Size = new System.Drawing.Size(58, 13);
            this.LblBaudrate.TabIndex = 6;
            this.LblBaudrate.Text = "Baud Rate";
            this.LblBaudrate.Click += new System.EventHandler(this.LblBaudrate_Click);
            // 
            // TxtDatosRecibidos
            // 
            this.TxtDatosRecibidos.Location = new System.Drawing.Point(135, 260);
            this.TxtDatosRecibidos.Name = "TxtDatosRecibidos";
            this.TxtDatosRecibidos.Size = new System.Drawing.Size(256, 20);
            this.TxtDatosRecibidos.TabIndex = 7;
            this.TxtDatosRecibidos.TextChanged += new System.EventHandler(this.TxtDatosRecibidos_TextChanged);
            // 
            // TxtDatosEnviar
            // 
            this.TxtDatosEnviar.Location = new System.Drawing.Point(135, 192);
            this.TxtDatosEnviar.Name = "TxtDatosEnviar";
            this.TxtDatosEnviar.Size = new System.Drawing.Size(256, 20);
            this.TxtDatosEnviar.TabIndex = 8;
            this.TxtDatosEnviar.TextChanged += new System.EventHandler(this.TxtDatosEnviar_TextChanged);
            // 
            // SpPuertos
            // 
            this.SpPuertos.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.DatoRecibido);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 332);
            this.Controls.Add(this.TxtDatosEnviar);
            this.Controls.Add(this.TxtDatosRecibidos);
            this.Controls.Add(this.LblBaudrate);
            this.Controls.Add(this.LblDatosIngreso);
            this.Controls.Add(this.CboBaudRate);
            this.Controls.Add(this.CboPuertos);
            this.Controls.Add(this.BtnEnviar);
            this.Controls.Add(this.BtnConectar);
            this.Controls.Add(this.BtnBuscar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnBuscar;
        private System.Windows.Forms.Button BtnConectar;
        private System.Windows.Forms.Button BtnEnviar;
        private System.Windows.Forms.ComboBox CboPuertos;
        private System.Windows.Forms.ComboBox CboBaudRate;
        private System.Windows.Forms.Label LblDatosIngreso;
        private System.Windows.Forms.Label LblBaudrate;
        private System.Windows.Forms.TextBox TxtDatosRecibidos;
        private System.Windows.Forms.TextBox TxtDatosEnviar;
        private System.IO.Ports.SerialPort SpPuertos;
    }
}

